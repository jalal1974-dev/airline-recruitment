import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'fs';

const envContent = readFileSync('.env', 'utf-8');
const envVars: Record<string, string> = {};
envContent.split('\n').forEach(line => {
  const [key, value] = line.split('=');
  if (key && value) {
    envVars[key.trim()] = value.trim();
  }
});

const supabaseUrl = envVars.VITE_SUPABASE_URL;
const supabaseKey = envVars.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing Supabase environment variables');
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function seed() {
  console.log('Starting database seed...');

  console.log('Creating admin user...');
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email: 'admin@jordanaviation.com',
    password: 'admin123456',
  });

  if (authError) {
    console.error('Admin user might already exist:', authError.message);
  } else if (authData.user) {
    const { error: profileError } = await supabase.from('profiles').insert({
      id: authData.user.id,
      full_name_en: 'System Administrator',
      full_name_ar: 'مدير النظام',
      phone: '+962 6 123 4567',
      nationality: 'Jordan',
      role: 'admin',
    });

    if (profileError) {
      console.error('Error creating admin profile:', profileError);
    } else {
      console.log('Admin user created successfully!');
    }
  }

  console.log('Creating sample jobs...');

  const jobs = [
    {
      title_en: 'Captain Pilot',
      title_ar: 'كابتن طيار',
      description_en: 'We are seeking an experienced Captain Pilot to join our flight operations team. The ideal candidate will have extensive experience in commercial aviation and a proven track record of safe flight operations.',
      description_ar: 'نبحث عن كابتن طيار ذو خبرة للانضمام إلى فريق عمليات الطيران لدينا. يجب أن يكون لدى المرشح المثالي خبرة واسعة في الطيران التجاري وسجل حافل بعمليات الطيران الآمنة.',
      department_en: 'Flight Operations',
      department_ar: 'عمليات الطيران',
      location_en: 'Amman, Jordan',
      location_ar: 'عمان، الأردن',
      employment_type: 'full-time',
      education_level: 'bachelor',
      experience_min: 8,
      experience_max: 20,
      salary_min: 8000,
      salary_max: 15000,
      salary_currency: 'USD',
      qualifications_en: [
        'Valid ATPL License',
        'Type rating on Boeing 737 or Airbus A320',
        'Minimum 5000 flight hours',
        'Strong leadership and decision-making skills',
        'Excellent communication in English',
      ],
      qualifications_ar: [
        'رخصة ATPL سارية المفعول',
        'تصنيف النوع على بوينج 737 أو إيرباص A320',
        'الحد الأدنى 5000 ساعة طيران',
        'مهارات قيادية قوية واتخاذ القرار',
        'مهارات تواصل ممتازة باللغة الإنجليزية',
      ],
      requirements_en: [
        'Current medical certificate',
        'Clean flight record',
        'Ability to work flexible schedules',
        'Strong knowledge of aviation regulations',
      ],
      requirements_ar: [
        'شهادة طبية سارية',
        'سجل طيران نظيف',
        'القدرة على العمل بجداول مرنة',
        'معرفة قوية بأنظمة الطيران',
      ],
      responsibilities_en: [
        'Ensure safe operation of all flights',
        'Lead and mentor first officers',
        'Maintain compliance with all regulations',
        'Provide excellent customer service',
        'Complete all required documentation',
      ],
      responsibilities_ar: [
        'ضمان التشغيل الآمن لجميع الرحلات',
        'قيادة وتوجيه الضباط الأوائل',
        'الحفاظ على الامتثال لجميع اللوائح',
        'تقديم خدمة عملاء ممتازة',
        'إكمال جميع الوثائق المطلوبة',
      ],
      skills: ['ATPL License', 'Boeing 737', 'Airbus A320', 'CRM', 'Leadership'],
      deadline: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      is_active: true,
      ai_min_experience: 8,
      ai_required_skills: ['ATPL License', 'Boeing 737'],
      ai_required_education: 'bachelor',
      ai_max_salary: 16000,
    },
    {
      title_en: 'Cabin Crew',
      title_ar: 'طاقم الضيافة الجوية',
      description_en: 'Join our award-winning cabin crew team and deliver exceptional service to our passengers. We are looking for enthusiastic individuals with excellent customer service skills.',
      description_ar: 'انضم إلى فريق طاقم الضيافة الجوية الحائز على جوائز وقدم خدمة استثنائية لركابنا. نبحث عن أفراد متحمسين يتمتعون بمهارات ممتازة في خدمة العملاء.',
      department_en: 'In-Flight Services',
      department_ar: 'خدمات الطيران',
      location_en: 'Amman, Jordan',
      location_ar: 'عمان، الأردن',
      employment_type: 'full-time',
      education_level: 'high-school',
      experience_min: 0,
      experience_max: 5,
      salary_min: 1500,
      salary_max: 3500,
      salary_currency: 'USD',
      qualifications_en: [
        'High school diploma or equivalent',
        'Excellent communication skills',
        'Fluency in English and Arabic',
        'Professional appearance',
        'Ability to swim',
      ],
      qualifications_ar: [
        'شهادة الثانوية العامة أو ما يعادلها',
        'مهارات تواصل ممتازة',
        'إتقان اللغتين الإنجليزية والعربية',
        'مظهر احترافي',
        'القدرة على السباحة',
      ],
      requirements_en: [
        'Minimum height 160cm',
        'No visible tattoos',
        'Willingness to relocate',
        'Flexibility with schedules',
      ],
      requirements_ar: [
        'الحد الأدنى للطول 160 سم',
        'عدم وجود وشم ظاهر',
        'الاستعداد للانتقال',
        'المرونة في الجداول الزمنية',
      ],
      responsibilities_en: [
        'Ensure passenger safety and comfort',
        'Provide food and beverage service',
        'Conduct safety demonstrations',
        'Handle emergency situations',
        'Maintain cabin cleanliness',
      ],
      responsibilities_ar: [
        'ضمان سلامة وراحة الركاب',
        'تقديم خدمة الطعام والشراب',
        'إجراء عروض السلامة',
        'التعامل مع حالات الطوارئ',
        'الحفاظ على نظافة المقصورة',
      ],
      skills: ['Customer Service', 'First Aid', 'Safety', 'Communication'],
      deadline: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      is_active: true,
      ai_min_experience: 0,
      ai_required_skills: ['Customer Service'],
      ai_required_education: 'high-school',
      ai_max_salary: 4000,
    },
    {
      title_en: 'Aircraft Maintenance Engineer',
      title_ar: 'مهندس صيانة طائرات',
      description_en: 'We are looking for a skilled Aircraft Maintenance Engineer to ensure the airworthiness of our fleet. The successful candidate will perform maintenance, repairs, and inspections on aircraft.',
      description_ar: 'نبحث عن مهندس صيانة طائرات ماهر لضمان صلاحية أسطولنا للطيران. سيقوم المرشح الناجح بإجراء الصيانة والإصلاحات والتفتيش على الطائرات.',
      department_en: 'Engineering',
      department_ar: 'الهندسة والصيانة',
      location_en: 'Queen Alia Airport',
      location_ar: 'مطار الملكة علياء',
      employment_type: 'full-time',
      education_level: 'bachelor',
      experience_min: 3,
      experience_max: 15,
      salary_min: 3000,
      salary_max: 7000,
      salary_currency: 'USD',
      qualifications_en: [
        "Bachelor's degree in Aerospace Engineering or related field",
        'EASA Part 66 License',
        'Experience with Boeing and/or Airbus aircraft',
        'Strong technical and analytical skills',
      ],
      qualifications_ar: [
        'درجة البكالوريوس في هندسة الطيران أو مجال ذي صلة',
        'رخصة EASA Part 66',
        'خبرة في طائرات بوينج و/أو إيرباص',
        'مهارات تقنية وتحليلية قوية',
      ],
      requirements_en: [
        'Knowledge of aviation regulations',
        'Ability to read technical manuals',
        'Attention to detail',
        'Willingness to work shifts',
      ],
      requirements_ar: [
        'معرفة بأنظمة الطيران',
        'القدرة على قراءة الأدلة الفنية',
        'الاهتمام بالتفاصيل',
        'الاستعداد للعمل بنظام الورديات',
      ],
      responsibilities_en: [
        'Perform scheduled maintenance on aircraft',
        'Diagnose and repair mechanical issues',
        'Ensure compliance with safety standards',
        'Maintain accurate maintenance records',
        'Collaborate with engineering team',
      ],
      responsibilities_ar: [
        'إجراء الصيانة المجدولة للطائرات',
        'تشخيص وإصلاح المشاكل الميكانيكية',
        'ضمان الامتثال لمعايير السلامة',
        'الحفاظ على سجلات صيانة دقيقة',
        'التعاون مع فريق الهندسة',
      ],
      skills: ['Aircraft Systems', 'Avionics', 'EASA Part 66', 'Troubleshooting'],
      deadline: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      is_active: true,
      ai_min_experience: 3,
      ai_required_skills: ['EASA Part 66', 'Aircraft Systems'],
      ai_required_education: 'bachelor',
      ai_max_salary: 8000,
    },
    {
      title_en: 'Airport Operations Manager',
      title_ar: 'مدير عمليات المطار',
      description_en: 'We are seeking an experienced Airport Operations Manager to oversee daily operations and ensure efficient airport management. The ideal candidate will have strong leadership and organizational skills.',
      description_ar: 'نبحث عن مدير عمليات مطار ذو خبرة للإشراف على العمليات اليومية وضمان الإدارة الفعالة للمطار. يجب أن يتمتع المرشح المثالي بمهارات قيادية وتنظيمية قوية.',
      department_en: 'Operations',
      department_ar: 'العمليات',
      location_en: 'Amman, Jordan',
      location_ar: 'عمان، الأردن',
      employment_type: 'full-time',
      education_level: 'bachelor',
      experience_min: 5,
      experience_max: 15,
      salary_min: 4000,
      salary_max: 8000,
      salary_currency: 'USD',
      qualifications_en: [
        "Bachelor's degree in Aviation Management or related field",
        'Minimum 5 years of airport operations experience',
        'Strong leadership and management skills',
        'Excellent problem-solving abilities',
      ],
      qualifications_ar: [
        'درجة البكالوريوس في إدارة الطيران أو مجال ذي صلة',
        'خبرة لا تقل عن 5 سنوات في عمليات المطار',
        'مهارات قيادية وإدارية قوية',
        'قدرات ممتازة في حل المشكلات',
      ],
      requirements_en: [
        'Knowledge of airport operations and regulations',
        'Experience with crisis management',
        'Strong communication skills',
        'Ability to work under pressure',
      ],
      requirements_ar: [
        'معرفة بعمليات المطار واللوائح',
        'خبرة في إدارة الأزمات',
        'مهارات تواصل قوية',
        'القدرة على العمل تحت الضغط',
      ],
      responsibilities_en: [
        'Oversee daily airport operations',
        'Manage staff and resources',
        'Ensure compliance with safety regulations',
        'Handle emergency situations',
        'Coordinate with airlines and stakeholders',
      ],
      responsibilities_ar: [
        'الإشراف على عمليات المطار اليومية',
        'إدارة الموظفين والموارد',
        'ضمان الامتثال للوائح السلامة',
        'التعامل مع حالات الطوارئ',
        'التنسيق مع شركات الطيران وأصحاب المصلحة',
      ],
      skills: ['Operations Management', 'Staff Management', 'Safety', 'Crisis Management'],
      deadline: new Date(Date.now() + 75 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      is_active: true,
      ai_min_experience: 5,
      ai_required_skills: ['Operations Management'],
      ai_required_education: 'bachelor',
      ai_max_salary: 9000,
    },
    {
      title_en: 'Customer Service Agent',
      title_ar: 'موظف خدمة العملاء',
      description_en: 'Join our customer service team and be the first point of contact for our valued passengers. We are looking for friendly, professional individuals with excellent communication skills.',
      description_ar: 'انضم إلى فريق خدمة العملاء لدينا وكن نقطة الاتصال الأولى لركابنا الكرام. نبحث عن أفراد ودودين ومحترفين يتمتعون بمهارات تواصل ممتازة.',
      department_en: 'Customer Experience',
      department_ar: 'تجربة العملاء',
      location_en: 'Amman, Jordan',
      location_ar: 'عمان، الأردن',
      employment_type: 'full-time',
      education_level: 'diploma',
      experience_min: 1,
      experience_max: 5,
      salary_min: 800,
      salary_max: 1500,
      salary_currency: 'USD',
      qualifications_en: [
        'Diploma or equivalent qualification',
        'Excellent customer service skills',
        'Fluency in English and Arabic',
        'Computer literacy',
        'Professional demeanor',
      ],
      qualifications_ar: [
        'دبلوم أو مؤهل معادل',
        'مهارات ممتازة في خدمة العملاء',
        'إتقان اللغتين الإنجليزية والعربية',
        'إلمام بالحاسوب',
        'سلوك مهني',
      ],
      requirements_en: [
        'Experience with reservation systems (Amadeus preferred)',
        'Ability to work shifts',
        'Strong problem-solving skills',
        'Patience and empathy',
      ],
      requirements_ar: [
        'خبرة في أنظمة الحجز (يفضل Amadeus)',
        'القدرة على العمل بنظام الورديات',
        'مهارات قوية في حل المشكلات',
        'الصبر والتعاطف',
      ],
      responsibilities_en: [
        'Assist passengers with check-in and boarding',
        'Handle customer inquiries and complaints',
        'Process ticket reservations and changes',
        'Provide flight information',
        'Maintain professional customer service standards',
      ],
      responsibilities_ar: [
        'مساعدة الركاب في تسجيل الوصول والصعود',
        'التعامل مع استفسارات وشكاوى العملاء',
        'معالجة حجوزات التذاكر والتغييرات',
        'تقديم معلومات الرحلات',
        'الحفاظ على معايير خدمة العملاء المهنية',
      ],
      skills: ['Customer Service', 'Communication', 'Amadeus', 'Ticketing'],
      deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      is_active: true,
      ai_min_experience: 1,
      ai_required_skills: ['Customer Service'],
      ai_required_education: 'diploma',
      ai_max_salary: 1800,
    },
  ];

  for (const job of jobs) {
    const { error } = await supabase.from('jobs').insert(job);
    if (error) {
      console.error(`Error creating job ${job.title_en}:`, error);
    } else {
      console.log(`Created job: ${job.title_en}`);
    }
  }

  console.log('\nDatabase seeding completed!');
  console.log('\n=== ADMIN CREDENTIALS ===');
  console.log('Email: admin@jordanaviation.com');
  console.log('Password: admin123456');
  console.log('========================\n');
}

seed().catch(console.error);
