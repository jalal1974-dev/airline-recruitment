import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../contexts/AuthContext';
import { Globe, LogOut, User } from 'lucide-react';
import { toast } from 'react-toastify';

export default function Navbar() {
  const { t, i18n } = useTranslation();
  const { user, profile, signOut, isAdmin } = useAuth();
  const navigate = useNavigate();
  const isRTL = i18n.language === 'ar';

  const toggleLanguage = () => {
    const newLang = i18n.language === 'en' ? 'ar' : 'en';
    i18n.changeLanguage(newLang);
    localStorage.setItem('language', newLang);
    document.documentElement.dir = newLang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = newLang;
  };

  const handleLogout = async () => {
    try {
      await signOut();
      toast.success(t('auth.logoutSuccess'));
      navigate('/');
    } catch (error) {
      toast.error(t('common.error'));
    }
  };

  return (
    <nav className="bg-[#1a365d] text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <img src="/download_jordan_aviation.jfif" alt="Jordan Aviation" className="h-10" />
            <span className="font-bold text-xl">{t('nav.logo')}</span>
          </Link>

          <div className="flex items-center space-x-4" style={{ flexDirection: isRTL ? 'row-reverse' : 'row', gap: '1rem' }}>
            <Link to="/jobs" className="hover:text-[#f6ad55] transition">
              {t('nav.jobs')}
            </Link>

            {user && !isAdmin && (
              <Link to="/my-applications" className="hover:text-[#f6ad55] transition">
                {t('nav.myApplications')}
              </Link>
            )}

            {isAdmin && (
              <Link to="/admin" className="hover:text-[#f6ad55] transition">
                {t('nav.adminDashboard')}
              </Link>
            )}

            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-1 hover:text-[#f6ad55] transition"
            >
              <Globe className="w-4 h-4" />
              <span>{i18n.language === 'en' ? 'العربية' : 'English'}</span>
            </button>

            {user ? (
              <div className="flex items-center space-x-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row', gap: '0.75rem' }}>
                <div className="flex items-center space-x-2">
                  <User className="w-4 h-4" />
                  <span className="text-sm">{profile?.full_name_en}</span>
                </div>
                <button
                  onClick={handleLogout}
                  className="flex items-center space-x-1 hover:text-[#f6ad55] transition"
                >
                  <LogOut className="w-4 h-4" />
                  <span>{t('nav.logout')}</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-3" style={{ flexDirection: isRTL ? 'row-reverse' : 'row', gap: '0.75rem' }}>
                <Link to="/login" className="hover:text-[#f6ad55] transition">
                  {t('nav.login')}
                </Link>
                <Link
                  to="/register"
                  className="bg-[#f6ad55] text-[#1a365d] px-4 py-2 rounded hover:bg-[#f6ad55]/90 transition"
                >
                  {t('nav.register')}
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
