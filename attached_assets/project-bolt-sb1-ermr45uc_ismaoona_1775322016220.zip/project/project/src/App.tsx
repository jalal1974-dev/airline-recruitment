import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './i18n/config';

import Home from './pages/Home';
import Jobs from './pages/Jobs';
import JobDetail from './pages/JobDetail';
import Login from './pages/Login';
import Register from './pages/Register';
import ApplicationForm from './pages/ApplicationForm';
import MyApplications from './pages/MyApplications';
import AdminDashboard from './pages/admin/AdminDashboard';
import ManageJobs from './pages/admin/ManageJobs';
import CreateJob from './pages/admin/CreateJob';
import JobApplications from './pages/admin/JobApplications';
import ApplicationDetail from './pages/admin/ApplicationDetail';
import AllApplications from './pages/admin/AllApplications';

function App() {
  const savedLanguage = localStorage.getItem('language') || 'en';
  document.documentElement.dir = savedLanguage === 'ar' ? 'rtl' : 'ltr';
  document.documentElement.lang = savedLanguage;

  return (
    <BrowserRouter>
      <AuthProvider>
        <div className="min-h-screen">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/jobs" element={<Jobs />} />
            <Route path="/jobs/:id" element={<JobDetail />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/apply/:jobId" element={<ApplicationForm />} />
            <Route path="/my-applications" element={<MyApplications />} />

            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/jobs" element={<ManageJobs />} />
            <Route path="/admin/jobs/create" element={<CreateJob />} />
            <Route path="/admin/jobs/edit/:id" element={<CreateJob />} />
            <Route path="/admin/jobs/:jobId/applications" element={<JobApplications />} />
            <Route path="/admin/applications" element={<AllApplications />} />
            <Route path="/admin/applications/:id" element={<ApplicationDetail />} />

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
          <ToastContainer position="top-right" autoClose={3000} />
        </div>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
