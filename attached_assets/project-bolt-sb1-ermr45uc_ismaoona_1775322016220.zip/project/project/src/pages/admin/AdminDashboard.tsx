import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase, Application, Job } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Briefcase, CheckCircle, XCircle, Clock, Users, FileText } from 'lucide-react';
import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';

export default function AdminDashboard() {
  const { t, i18n } = useTranslation();
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalJobs: 0,
    activeJobs: 0,
    totalApplications: 0,
    pendingReview: 0,
    shortlisted: 0,
    rejected: 0,
    totalApplicants: 0,
  });
  const [recentApplications, setRecentApplications] = useState<(Application & { jobs: Job })[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
      return;
    }
    fetchDashboardData();
  }, [isAdmin]);

  async function fetchDashboardData() {
    try {
      const [jobsRes, applicationsRes, recentRes] = await Promise.all([
        supabase.from('jobs').select('*', { count: 'exact' }),
        supabase.from('applications').select('*', { count: 'exact' }),
        supabase.from('applications').select('*, jobs(*)').order('applied_at', { ascending: false }).limit(10),
      ]);

      if (jobsRes.error) throw jobsRes.error;
      if (applicationsRes.error) throw applicationsRes.error;
      if (recentRes.error) throw recentRes.error;

      const jobs = jobsRes.data || [];
      const applications = applicationsRes.data || [];

      setStats({
        totalJobs: jobs.length,
        activeJobs: jobs.filter(j => j.is_active).length,
        totalApplications: applications.length,
        pendingReview: applications.filter(a => a.status === 'pending').length,
        shortlisted: applications.filter(a => a.status === 'shortlisted' || a.status === 'ai-shortlisted').length,
        rejected: applications.filter(a => a.status === 'rejected' || a.status === 'ai-rejected').length,
        totalApplicants: new Set(applications.map(a => a.user_id)).size,
      });

      setRecentApplications(recentRes.data || []);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  }

  const getStatusColor = (status: string) => {
    const statusColors: { [key: string]: string } = {
      pending: 'bg-yellow-100 text-yellow-700',
      reviewing: 'bg-blue-100 text-blue-700',
      shortlisted: 'bg-green-100 text-green-700',
      rejected: 'bg-red-100 text-red-700',
      interview: 'bg-purple-100 text-purple-700',
      accepted: 'bg-green-200 text-green-800',
      'ai-shortlisted': 'bg-teal-100 text-teal-700',
      'ai-rejected': 'bg-orange-100 text-orange-700',
    };
    return statusColors[status] || 'bg-gray-100 text-gray-700';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-xl text-gray-600">{t('common.loading')}</p>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
      <Navbar />

      <div className="flex-1 max-w-7xl mx-auto px-4 py-12 w-full">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold text-[#1a365d]">{t('admin.dashboard')}</h1>
          <div className="flex gap-3">
            <Link
              to="/admin/jobs"
              className="bg-[#1a365d] text-white px-6 py-3 rounded-lg hover:bg-[#1a365d]/90 transition"
            >
              {t('admin.manageJobs')}
            </Link>
            <Link
              to="/admin/applications"
              className="bg-[#f6ad55] text-[#1a365d] px-6 py-3 rounded-lg hover:bg-[#f6ad55]/90 transition"
            >
              {t('admin.allApplications')}
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-gray-600">{t('admin.stats.totalJobs')}</h3>
              <Briefcase className="w-8 h-8 text-blue-600" />
            </div>
            <p className="text-3xl font-bold text-[#1a365d]">{stats.totalJobs}</p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-gray-600">{t('admin.stats.activeJobs')}</h3>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <p className="text-3xl font-bold text-[#1a365d]">{stats.activeJobs}</p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-gray-600">{t('admin.stats.totalApplications')}</h3>
              <FileText className="w-8 h-8 text-purple-600" />
            </div>
            <p className="text-3xl font-bold text-[#1a365d]">{stats.totalApplications}</p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-gray-600">{t('admin.stats.pendingReview')}</h3>
              <Clock className="w-8 h-8 text-yellow-600" />
            </div>
            <p className="text-3xl font-bold text-[#1a365d]">{stats.pendingReview}</p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-gray-600">{t('admin.stats.shortlisted')}</h3>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <p className="text-3xl font-bold text-[#1a365d]">{stats.shortlisted}</p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-gray-600">{t('admin.stats.rejected')}</h3>
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
            <p className="text-3xl font-bold text-[#1a365d]">{stats.rejected}</p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-medium text-gray-600">{t('admin.stats.totalApplicants')}</h3>
              <Users className="w-8 h-8 text-blue-600" />
            </div>
            <p className="text-3xl font-bold text-[#1a365d]">{stats.totalApplicants}</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-[#1a365d] mb-6">{t('admin.recentApplications')}</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">{t('admin.applicantName')}</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">{t('admin.jobTitle')}</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">{t('admin.date')}</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">{t('admin.status')}</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">{t('admin.actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {recentApplications.map((application) => (
                  <tr key={application.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm text-gray-900">{application.full_name_en}</td>
                    <td className="px-4 py-3 text-sm text-gray-900">
                      {i18n.language === 'ar' ? application.jobs.title_ar : application.jobs.title_en}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">
                      {new Date(application.applied_at).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(application.status)}`}>
                        {application.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <Link
                        to={`/admin/applications/${application.id}`}
                        className="text-[#1a365d] hover:text-[#f6ad55] font-medium"
                      >
                        {t('admin.view')}
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
