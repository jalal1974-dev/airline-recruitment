import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase, Job } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { toast } from 'react-toastify';
import { Plus, Trash2 } from 'lucide-react';
import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';

export default function CreateJob() {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [skillInput, setSkillInput] = useState('');
  const [aiSkillInput, setAiSkillInput] = useState('');

  const [formData, setFormData] = useState({
    title_en: '',
    title_ar: '',
    description_en: '',
    description_ar: '',
    department_en: '',
    department_ar: '',
    location_en: '',
    location_ar: '',
    employment_type: 'full-time',
    education_level: 'bachelor',
    experience_min: 0,
    experience_max: 0,
    salary_min: 0,
    salary_max: 0,
    salary_currency: 'USD',
    deadline: '',
    ai_min_experience: 0,
    ai_required_education: '',
    ai_max_salary: 0,
    ai_custom_criteria: '',
  });

  const [qualificationsEn, setQualificationsEn] = useState<string[]>(['']);
  const [qualificationsAr, setQualificationsAr] = useState<string[]>(['']);
  const [requirementsEn, setRequirementsEn] = useState<string[]>(['']);
  const [requirementsAr, setRequirementsAr] = useState<string[]>(['']);
  const [responsibilitiesEn, setResponsibilitiesEn] = useState<string[]>(['']);
  const [responsibilitiesAr, setResponsibilitiesAr] = useState<string[]>(['']);
  const [skills, setSkills] = useState<string[]>([]);
  const [aiRequiredSkills, setAiRequiredSkills] = useState<string[]>([]);

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
      return;
    }
    if (id) {
      fetchJob();
    }
  }, [id, isAdmin]);

  async function fetchJob() {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('id', id)
        .maybeSingle();

      if (error) throw error;
      if (!data) return;

      setFormData({
        title_en: data.title_en,
        title_ar: data.title_ar,
        description_en: data.description_en,
        description_ar: data.description_ar,
        department_en: data.department_en,
        department_ar: data.department_ar,
        location_en: data.location_en,
        location_ar: data.location_ar,
        employment_type: data.employment_type,
        education_level: data.education_level,
        experience_min: data.experience_min,
        experience_max: data.experience_max,
        salary_min: data.salary_min,
        salary_max: data.salary_max,
        salary_currency: data.salary_currency,
        deadline: data.deadline,
        ai_min_experience: data.ai_min_experience || 0,
        ai_required_education: data.ai_required_education || '',
        ai_max_salary: data.ai_max_salary || 0,
        ai_custom_criteria: data.ai_custom_criteria || '',
      });

      setQualificationsEn(data.qualifications_en.length > 0 ? data.qualifications_en : ['']);
      setQualificationsAr(data.qualifications_ar.length > 0 ? data.qualifications_ar : ['']);
      setRequirementsEn(data.requirements_en.length > 0 ? data.requirements_en : ['']);
      setRequirementsAr(data.requirements_ar.length > 0 ? data.requirements_ar : ['']);
      setResponsibilitiesEn(data.responsibilities_en.length > 0 ? data.responsibilities_en : ['']);
      setResponsibilitiesAr(data.responsibilities_ar.length > 0 ? data.responsibilities_ar : ['']);
      setSkills(data.skills || []);
      setAiRequiredSkills(data.ai_required_skills || []);
    } catch (error) {
      console.error('Error fetching job:', error);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    try {
      const jobData = {
        ...formData,
        qualifications_en: qualificationsEn.filter(q => q.trim()),
        qualifications_ar: qualificationsAr.filter(q => q.trim()),
        requirements_en: requirementsEn.filter(r => r.trim()),
        requirements_ar: requirementsAr.filter(r => r.trim()),
        responsibilities_en: responsibilitiesEn.filter(r => r.trim()),
        responsibilities_ar: responsibilitiesAr.filter(r => r.trim()),
        skills,
        ai_required_skills: aiRequiredSkills,
      };

      if (id) {
        const { error } = await supabase
          .from('jobs')
          .update(jobData)
          .eq('id', id);

        if (error) throw error;
        toast.success(t('createJob.jobUpdated'));
      } else {
        const { error } = await supabase
          .from('jobs')
          .insert(jobData);

        if (error) throw error;
        toast.success(t('createJob.jobCreated'));
      }

      navigate('/admin/jobs');
    } catch (error) {
      console.error('Error saving job:', error);
      toast.error(t('common.error'));
    } finally {
      setLoading(false);
    }
  }

  const addSkill = () => {
    if (skillInput.trim()) {
      setSkills([...skills, skillInput.trim()]);
      setSkillInput('');
    }
  };

  const addAiSkill = () => {
    if (aiSkillInput.trim()) {
      setAiRequiredSkills([...aiRequiredSkills, aiSkillInput.trim()]);
      setAiSkillInput('');
    }
  };

  return (
    <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
      <Navbar />

      <div className="flex-1 max-w-6xl mx-auto px-4 py-12 w-full">
        <h1 className="text-4xl font-bold text-[#1a365d] mb-8">
          {id ? t('createJob.editTitle') : t('createJob.title')}
        </h1>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('createJob.basicInfo')}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.titleEn')} *
                </label>
                <input
                  type="text"
                  required
                  value={formData.title_en}
                  onChange={(e) => setFormData({ ...formData, title_en: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.titleAr')} *
                </label>
                <input
                  type="text"
                  required
                  value={formData.title_ar}
                  onChange={(e) => setFormData({ ...formData, title_ar: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.descriptionEn')} *
                </label>
                <textarea
                  required
                  rows={4}
                  value={formData.description_en}
                  onChange={(e) => setFormData({ ...formData, description_en: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.descriptionAr')} *
                </label>
                <textarea
                  required
                  rows={4}
                  value={formData.description_ar}
                  onChange={(e) => setFormData({ ...formData, description_ar: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.departmentEn')} *
                </label>
                <input
                  type="text"
                  required
                  value={formData.department_en}
                  onChange={(e) => setFormData({ ...formData, department_en: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.departmentAr')} *
                </label>
                <input
                  type="text"
                  required
                  value={formData.department_ar}
                  onChange={(e) => setFormData({ ...formData, department_ar: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.locationEn')} *
                </label>
                <input
                  type="text"
                  required
                  value={formData.location_en}
                  onChange={(e) => setFormData({ ...formData, location_en: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.locationAr')} *
                </label>
                <input
                  type="text"
                  required
                  value={formData.location_ar}
                  onChange={(e) => setFormData({ ...formData, location_ar: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.employmentType')} *
                </label>
                <select
                  required
                  value={formData.employment_type}
                  onChange={(e) => setFormData({ ...formData, employment_type: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                >
                  <option value="full-time">Full Time</option>
                  <option value="part-time">Part Time</option>
                  <option value="contract">Contract</option>
                  <option value="internship">Internship</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.educationLevel')} *
                </label>
                <select
                  required
                  value={formData.education_level}
                  onChange={(e) => setFormData({ ...formData, education_level: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                >
                  <option value="high-school">High School</option>
                  <option value="diploma">Diploma</option>
                  <option value="bachelor">Bachelor</option>
                  <option value="master">Master</option>
                  <option value="phd">PhD</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.experienceMin')}
                </label>
                <input
                  type="number"
                  min="0"
                  value={formData.experience_min}
                  onChange={(e) => setFormData({ ...formData, experience_min: parseInt(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.experienceMax')}
                </label>
                <input
                  type="number"
                  min="0"
                  value={formData.experience_max}
                  onChange={(e) => setFormData({ ...formData, experience_max: parseInt(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.salaryMin')}
                </label>
                <input
                  type="number"
                  min="0"
                  value={formData.salary_min}
                  onChange={(e) => setFormData({ ...formData, salary_min: parseFloat(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.salaryMax')}
                </label>
                <input
                  type="number"
                  min="0"
                  value={formData.salary_max}
                  onChange={(e) => setFormData({ ...formData, salary_max: parseFloat(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.currency')}
                </label>
                <select
                  value={formData.salary_currency}
                  onChange={(e) => setFormData({ ...formData, salary_currency: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                >
                  <option value="USD">USD</option>
                  <option value="JOD">JOD</option>
                  <option value="EUR">EUR</option>
                  <option value="SAR">SAR</option>
                  <option value="AED">AED</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.deadline')} *
                </label>
                <input
                  type="date"
                  required
                  value={formData.deadline}
                  onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('createJob.qualifications')}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">English</label>
                {qualificationsEn.map((qual, index) => (
                  <div key={index} className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={qual}
                      onChange={(e) => {
                        const updated = [...qualificationsEn];
                        updated[index] = e.target.value;
                        setQualificationsEn(updated);
                      }}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                    />
                    {qualificationsEn.length > 1 && (
                      <button
                        type="button"
                        onClick={() => setQualificationsEn(qualificationsEn.filter((_, i) => i !== index))}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    )}
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => setQualificationsEn([...qualificationsEn, ''])}
                  className="flex items-center text-[#1a365d] hover:text-[#f6ad55]"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  {t('createJob.addQualification')}
                </button>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Arabic</label>
                {qualificationsAr.map((qual, index) => (
                  <div key={index} className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={qual}
                      onChange={(e) => {
                        const updated = [...qualificationsAr];
                        updated[index] = e.target.value;
                        setQualificationsAr(updated);
                      }}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                    />
                    {qualificationsAr.length > 1 && (
                      <button
                        type="button"
                        onClick={() => setQualificationsAr(qualificationsAr.filter((_, i) => i !== index))}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    )}
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => setQualificationsAr([...qualificationsAr, ''])}
                  className="flex items-center text-[#1a365d] hover:text-[#f6ad55]"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  {t('createJob.addQualification')}
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('createJob.requirements')}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">English</label>
                {requirementsEn.map((req, index) => (
                  <div key={index} className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={req}
                      onChange={(e) => {
                        const updated = [...requirementsEn];
                        updated[index] = e.target.value;
                        setRequirementsEn(updated);
                      }}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                    />
                    {requirementsEn.length > 1 && (
                      <button
                        type="button"
                        onClick={() => setRequirementsEn(requirementsEn.filter((_, i) => i !== index))}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    )}
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => setRequirementsEn([...requirementsEn, ''])}
                  className="flex items-center text-[#1a365d] hover:text-[#f6ad55]"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  {t('createJob.addRequirement')}
                </button>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Arabic</label>
                {requirementsAr.map((req, index) => (
                  <div key={index} className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={req}
                      onChange={(e) => {
                        const updated = [...requirementsAr];
                        updated[index] = e.target.value;
                        setRequirementsAr(updated);
                      }}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                    />
                    {requirementsAr.length > 1 && (
                      <button
                        type="button"
                        onClick={() => setRequirementsAr(requirementsAr.filter((_, i) => i !== index))}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    )}
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => setRequirementsAr([...requirementsAr, ''])}
                  className="flex items-center text-[#1a365d] hover:text-[#f6ad55]"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  {t('createJob.addRequirement')}
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('createJob.responsibilities')}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">English</label>
                {responsibilitiesEn.map((resp, index) => (
                  <div key={index} className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={resp}
                      onChange={(e) => {
                        const updated = [...responsibilitiesEn];
                        updated[index] = e.target.value;
                        setResponsibilitiesEn(updated);
                      }}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                    />
                    {responsibilitiesEn.length > 1 && (
                      <button
                        type="button"
                        onClick={() => setResponsibilitiesEn(responsibilitiesEn.filter((_, i) => i !== index))}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    )}
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => setResponsibilitiesEn([...responsibilitiesEn, ''])}
                  className="flex items-center text-[#1a365d] hover:text-[#f6ad55]"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  {t('createJob.addResponsibility')}
                </button>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Arabic</label>
                {responsibilitiesAr.map((resp, index) => (
                  <div key={index} className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={resp}
                      onChange={(e) => {
                        const updated = [...responsibilitiesAr];
                        updated[index] = e.target.value;
                        setResponsibilitiesAr(updated);
                      }}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                    />
                    {responsibilitiesAr.length > 1 && (
                      <button
                        type="button"
                        onClick={() => setResponsibilitiesAr(responsibilitiesAr.filter((_, i) => i !== index))}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    )}
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => setResponsibilitiesAr([...responsibilitiesAr, ''])}
                  className="flex items-center text-[#1a365d] hover:text-[#f6ad55]"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  {t('createJob.addResponsibility')}
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('createJob.skills')}</h2>
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
                placeholder="Enter a skill..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
              />
              <button
                type="button"
                onClick={addSkill}
                className="px-4 py-2 bg-[#1a365d] text-white rounded-lg hover:bg-[#1a365d]/90"
              >
                Add
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {skills.map((skill, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full flex items-center"
                >
                  {skill}
                  <button
                    type="button"
                    onClick={() => setSkills(skills.filter((_, i) => i !== index))}
                    className="ml-2 text-red-600 hover:text-red-800"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('createJob.aiCriteria')}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.aiMinExperience')}
                </label>
                <input
                  type="number"
                  min="0"
                  value={formData.ai_min_experience}
                  onChange={(e) => setFormData({ ...formData, ai_min_experience: parseInt(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.aiRequiredEducation')}
                </label>
                <select
                  value={formData.ai_required_education}
                  onChange={(e) => setFormData({ ...formData, ai_required_education: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                >
                  <option value="">Not specified</option>
                  <option value="high-school">High School</option>
                  <option value="diploma">Diploma</option>
                  <option value="bachelor">Bachelor</option>
                  <option value="master">Master</option>
                  <option value="phd">PhD</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.aiMaxSalary')}
                </label>
                <input
                  type="number"
                  min="0"
                  value={formData.ai_max_salary}
                  onChange={(e) => setFormData({ ...formData, ai_max_salary: parseFloat(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.aiRequiredSkills')}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={aiSkillInput}
                    onChange={(e) => setAiSkillInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addAiSkill())}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                  />
                  <button
                    type="button"
                    onClick={addAiSkill}
                    className="px-4 py-2 bg-[#1a365d] text-white rounded-lg hover:bg-[#1a365d]/90"
                  >
                    Add
                  </button>
                </div>
                <div className="flex flex-wrap gap-2 mt-2">
                  {aiRequiredSkills.map((skill, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-teal-100 text-teal-700 rounded-full flex items-center text-sm"
                    >
                      {skill}
                      <button
                        type="button"
                        onClick={() => setAiRequiredSkills(aiRequiredSkills.filter((_, i) => i !== index))}
                        className="ml-2 text-red-600 hover:text-red-800"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {t('createJob.aiCustomCriteria')}
                </label>
                <textarea
                  rows={3}
                  value={formData.ai_custom_criteria}
                  onChange={(e) => setFormData({ ...formData, ai_custom_criteria: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#f6ad55] text-[#1a365d] px-8 py-4 rounded-lg text-lg font-bold hover:bg-[#f6ad55]/90 transition disabled:opacity-50"
          >
            {loading ? t('common.loading') : t('createJob.saveJob')}
          </button>
        </form>
      </div>

      <Footer />
    </div>
  );
}
