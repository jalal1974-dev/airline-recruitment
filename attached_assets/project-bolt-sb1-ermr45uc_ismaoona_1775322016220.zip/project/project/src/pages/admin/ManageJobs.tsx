import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase, Job } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { toast } from 'react-toastify';
import { CreditCard as Edit, Trash2, Eye, ToggleLeft, ToggleRight, Plus } from 'lucide-react';
import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';

export default function ManageJobs() {
  const { t, i18n } = useTranslation();
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
      return;
    }
    fetchJobs();
  }, [isAdmin]);

  async function fetchJobs() {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setJobs(data || []);
    } catch (error) {
      console.error('Error fetching jobs:', error);
    } finally {
      setLoading(false);
    }
  }

  async function toggleJobStatus(jobId: string, currentStatus: boolean) {
    try {
      const { error } = await supabase
        .from('jobs')
        .update({ is_active: !currentStatus })
        .eq('id', jobId);

      if (error) throw error;
      toast.success('Job status updated');
      fetchJobs();
    } catch (error) {
      toast.error('Failed to update job status');
    }
  }

  async function deleteJob(jobId: string) {
    if (!confirm(t('admin.deleteConfirm'))) return;

    try {
      const { error } = await supabase
        .from('jobs')
        .delete()
        .eq('id', jobId);

      if (error) throw error;
      toast.success(t('createJob.jobDeleted'));
      fetchJobs();
    } catch (error) {
      toast.error(t('common.error'));
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-xl text-gray-600">{t('common.loading')}</p>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
      <Navbar />

      <div className="flex-1 max-w-7xl mx-auto px-4 py-12 w-full">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold text-[#1a365d]">{t('admin.manageJobs')}</h1>
          <Link
            to="/admin/jobs/create"
            className="bg-[#f6ad55] text-[#1a365d] px-6 py-3 rounded-lg font-semibold hover:bg-[#f6ad55]/90 transition flex items-center"
          >
            <Plus className="w-5 h-5 mr-2" />
            {t('admin.createJob')}
          </Link>
        </div>

        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Title</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Department</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Type</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Status</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">{t('admin.applicationsCount')}</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">{t('admin.actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {jobs.map((job) => (
                  <tr key={job.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm text-gray-900">
                      {i18n.language === 'ar' ? job.title_ar : job.title_en}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">
                      {i18n.language === 'ar' ? job.department_ar : job.department_en}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">{job.employment_type}</td>
                    <td className="px-4 py-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        job.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                      }`}>
                        {job.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">-</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-2">
                        <Link
                          to={`/admin/jobs/${job.id}/applications`}
                          className="text-blue-600 hover:text-blue-800"
                          title={t('admin.viewApplications')}
                        >
                          <Eye className="w-5 h-5" />
                        </Link>
                        <Link
                          to={`/admin/jobs/edit/${job.id}`}
                          className="text-[#1a365d] hover:text-[#f6ad55]"
                          title={t('admin.edit')}
                        >
                          <Edit className="w-5 h-5" />
                        </Link>
                        <button
                          onClick={() => toggleJobStatus(job.id, job.is_active)}
                          className="text-purple-600 hover:text-purple-800"
                          title={t('admin.toggle')}
                        >
                          {job.is_active ? <ToggleRight className="w-5 h-5" /> : <ToggleLeft className="w-5 h-5" />}
                        </button>
                        <button
                          onClick={() => deleteJob(job.id)}
                          className="text-red-600 hover:text-red-800"
                          title={t('admin.delete')}
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
