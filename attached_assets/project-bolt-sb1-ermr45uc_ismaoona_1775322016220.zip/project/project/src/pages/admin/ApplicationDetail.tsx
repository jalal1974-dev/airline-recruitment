import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase, Application, Job } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { toast } from 'react-toastify';
import { Download, CheckCircle, XCircle } from 'lucide-react';
import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';

export default function ApplicationDetail() {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [application, setApplication] = useState<(Application & { jobs: Job }) | null>(null);
  const [status, setStatus] = useState('');
  const [adminNotes, setAdminNotes] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
      return;
    }
    if (id) {
      fetchApplication();
    }
  }, [id, isAdmin]);

  async function fetchApplication() {
    try {
      const { data, error } = await supabase
        .from('applications')
        .select('*, jobs(*)')
        .eq('id', id)
        .maybeSingle();

      if (error) throw error;
      setApplication(data);
      setStatus(data?.status || '');
      setAdminNotes(data?.admin_notes || '');
    } catch (error) {
      console.error('Error fetching application:', error);
    } finally {
      setLoading(false);
    }
  }

  async function updateStatus() {
    try {
      const { error } = await supabase
        .from('applications')
        .update({ status })
        .eq('id', id);

      if (error) throw error;
      toast.success('Status updated');
      fetchApplication();
    } catch (error) {
      toast.error(t('common.error'));
    }
  }

  async function updateNotes() {
    try {
      const { error } = await supabase
        .from('applications')
        .update({ admin_notes: adminNotes })
        .eq('id', id);

      if (error) throw error;
      toast.success('Notes saved');
    } catch (error) {
      toast.error(t('common.error'));
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-green-600';
    if (score >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-xl text-gray-600">{t('common.loading')}</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (!application) {
    return (
      <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-xl text-gray-600">Application not found</p>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
      <Navbar />

      <div className="flex-1 max-w-6xl mx-auto px-4 py-12 w-full">
        <Link to={`/admin/jobs/${application.job_id}/applications`} className="text-[#1a365d] hover:text-[#f6ad55] mb-6 inline-block">
          ← {t('common.back')}
        </Link>

        <h1 className="text-4xl font-bold text-[#1a365d] mb-2">{application.full_name_en}</h1>
        <p className="text-lg text-gray-600 mb-8">Application for {application.jobs.title_en}</p>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-2xl font-bold text-[#1a365d] mb-4">Personal Information</h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Full Name (EN)</p>
                  <p className="font-semibold">{application.full_name_en}</p>
                </div>
                {application.full_name_ar && (
                  <div>
                    <p className="text-sm text-gray-600">Full Name (AR)</p>
                    <p className="font-semibold">{application.full_name_ar}</p>
                  </div>
                )}
                <div>
                  <p className="text-sm text-gray-600">Email</p>
                  <p className="font-semibold">{application.email}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Phone</p>
                  <p className="font-semibold">{application.phone}</p>
                </div>
                {application.nationality && (
                  <div>
                    <p className="text-sm text-gray-600">Nationality</p>
                    <p className="font-semibold">{application.nationality}</p>
                  </div>
                )}
                {application.date_of_birth && (
                  <div>
                    <p className="text-sm text-gray-600">Date of Birth</p>
                    <p className="font-semibold">{new Date(application.date_of_birth).toLocaleDateString()}</p>
                  </div>
                )}
                {application.gender && (
                  <div>
                    <p className="text-sm text-gray-600">Gender</p>
                    <p className="font-semibold">{application.gender}</p>
                  </div>
                )}
                {application.address_en && (
                  <div className="col-span-2">
                    <p className="text-sm text-gray-600">Address</p>
                    <p className="font-semibold">{application.address_en}</p>
                  </div>
                )}
              </div>
            </div>

            {application.education && application.education.length > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-bold text-[#1a365d] mb-4">Education</h2>
                <div className="space-y-4">
                  {application.education.map((edu, index) => (
                    <div key={index} className="border-l-4 border-[#1a365d] pl-4">
                      <p className="font-semibold text-lg">{edu.degree}</p>
                      <p className="text-gray-600">{edu.institution}</p>
                      <p className="text-sm text-gray-600">{edu.field} • {edu.year} • GPA: {edu.gpa}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {application.experience && application.experience.length > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-bold text-[#1a365d] mb-4">Work Experience</h2>
                <div className="space-y-4">
                  {application.experience.map((exp, index) => (
                    <div key={index} className="border-l-4 border-[#f6ad55] pl-4">
                      <p className="font-semibold text-lg">{exp.title}</p>
                      <p className="text-gray-600">{exp.company}</p>
                      <p className="text-sm text-gray-600">
                        {exp.start_date} - {exp.current ? 'Present' : exp.end_date}
                      </p>
                      {exp.description && <p className="mt-2 text-gray-700">{exp.description}</p>}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {application.skills && application.skills.length > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-bold text-[#1a365d] mb-4">Skills</h2>
                <div className="flex flex-wrap gap-2">
                  {application.skills.map((skill, index) => (
                    <span key={index} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {application.languages && application.languages.length > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-bold text-[#1a365d] mb-4">Languages</h2>
                <div className="space-y-2">
                  {application.languages.map((lang, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="font-semibold">{lang.language}</span>
                      <span className="text-sm text-gray-600">{lang.proficiency}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-2xl font-bold text-[#1a365d] mb-4">Documents & Salary</h2>
              <div className="space-y-4">
                {application.resume_url && (
                  <div>
                    <p className="text-sm text-gray-600 mb-2">Resume</p>
                    <a
                      href={application.resume_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center text-[#1a365d] hover:text-[#f6ad55]"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      {t('admin.downloadResume')}
                    </a>
                  </div>
                )}
                {application.cover_letter && (
                  <div>
                    <p className="text-sm text-gray-600 mb-2">Cover Letter</p>
                    <p className="text-gray-700 whitespace-pre-line">{application.cover_letter}</p>
                  </div>
                )}
                <div className="grid grid-cols-3 gap-4 pt-4 border-t">
                  <div>
                    <p className="text-sm text-gray-600">Experience</p>
                    <p className="font-semibold">{application.total_experience} years</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Education</p>
                    <p className="font-semibold">{application.highest_education || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Expected Salary</p>
                    <p className="font-semibold">
                      {application.expected_salary} {application.salary_currency}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {application.ai_score !== null && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('admin.aiAnalysis')}</h2>
                <div className="text-center mb-4">
                  <p className="text-sm text-gray-600">{t('admin.aiScore')}</p>
                  <p className={`text-5xl font-bold ${getScoreColor(application.ai_score)}`}>
                    {application.ai_score.toFixed(0)}
                  </p>
                  <p className="text-sm text-gray-600">out of 100</p>
                </div>
                {application.ai_analysis && (
                  <div className="mt-4">
                    <p className="text-sm text-gray-700 whitespace-pre-line">{application.ai_analysis}</p>
                  </div>
                )}
              </div>
            )}

            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('admin.updateStatus')}</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                  >
                    <option value="pending">Pending</option>
                    <option value="reviewing">Reviewing</option>
                    <option value="shortlisted">Shortlisted</option>
                    <option value="rejected">Rejected</option>
                    <option value="interview">Interview</option>
                    <option value="accepted">Accepted</option>
                    <option value="ai-shortlisted">AI Shortlisted</option>
                    <option value="ai-rejected">AI Rejected</option>
                  </select>
                </div>
                <button
                  onClick={updateStatus}
                  className="w-full bg-[#1a365d] text-white px-4 py-2 rounded-lg hover:bg-[#1a365d]/90 transition"
                >
                  {t('common.save')}
                </button>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('admin.adminNotes')}</h2>
              <div className="space-y-4">
                <textarea
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  rows={6}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
                  placeholder="Add notes about this application..."
                />
                <button
                  onClick={updateNotes}
                  className="w-full bg-[#f6ad55] text-[#1a365d] px-4 py-2 rounded-lg hover:bg-[#f6ad55]/90 transition font-semibold"
                >
                  {t('admin.saveNotes')}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
