import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase, Application, Job } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { toast } from 'react-toastify';
import { Bot } from 'lucide-react';
import Navbar from '../../components/Navbar';
import Footer from '../../components/Footer';

export default function JobApplications() {
  const { jobId } = useParams<{ jobId: string }>();
  const { t } = useTranslation();
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  const [job, setJob] = useState<Job | null>(null);
  const [applications, setApplications] = useState<Application[]>([]);
  const [filteredApplications, setFilteredApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [aiFilterLoading, setAiFilterLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState('');

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
      return;
    }
    if (jobId) {
      fetchData();
    }
  }, [jobId, isAdmin]);

  useEffect(() => {
    filterApplications();
  }, [applications, statusFilter]);

  async function fetchData() {
    try {
      const [jobRes, appsRes] = await Promise.all([
        supabase.from('jobs').select('*').eq('id', jobId).maybeSingle(),
        supabase.from('applications').select('*').eq('job_id', jobId).order('applied_at', { ascending: false }),
      ]);

      if (jobRes.error) throw jobRes.error;
      if (appsRes.error) throw appsRes.error;

      setJob(jobRes.data);
      setApplications(appsRes.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  }

  function filterApplications() {
    let filtered = applications;
    if (statusFilter) {
      filtered = filtered.filter(app => app.status === statusFilter);
    }
    setFilteredApplications(filtered);
  }

  async function runAIFilter() {
    if (!job) return;

    setAiFilterLoading(true);
    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-filter`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ jobId: job.id }),
        }
      );

      if (!response.ok) throw new Error('AI filter failed');

      const result = await response.json();
      toast.success(
        `${t('admin.aiFilterComplete')}: ${result.shortlisted} ${t('admin.shortlisted')}, ${result.forReview} ${t('admin.forReview')}, ${result.rejected} ${t('admin.rejected')}`
      );
      fetchData();
    } catch (error) {
      console.error('Error running AI filter:', error);
      toast.error(t('common.error'));
    } finally {
      setAiFilterLoading(false);
    }
  }

  const getStatusColor = (status: string) => {
    const statusColors: { [key: string]: string } = {
      pending: 'bg-yellow-100 text-yellow-700',
      reviewing: 'bg-blue-100 text-blue-700',
      shortlisted: 'bg-green-100 text-green-700',
      rejected: 'bg-red-100 text-red-700',
      interview: 'bg-purple-100 text-purple-700',
      accepted: 'bg-green-200 text-green-800',
      'ai-shortlisted': 'bg-teal-100 text-teal-700',
      'ai-rejected': 'bg-orange-100 text-orange-700',
    };
    return statusColors[status] || 'bg-gray-100 text-gray-700';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-xl text-gray-600">{t('common.loading')}</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-xl text-gray-600">Job not found</p>
        </div>
        <Footer />
      </div>
    );
  }

  const pendingCount = applications.filter(a => a.status === 'pending').length;

  return (
    <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
      <Navbar />

      <div className="flex-1 max-w-7xl mx-auto px-4 py-12 w-full">
        <Link to="/admin/jobs" className="text-[#1a365d] hover:text-[#f6ad55] mb-6 inline-block">
          ← {t('common.back')}
        </Link>

        <h1 className="text-4xl font-bold text-[#1a365d] mb-2">{job.title_en}</h1>
        <p className="text-lg text-gray-600 mb-8">{applications.length} Applications</p>

        {pendingCount > 0 && (
          <button
            onClick={runAIFilter}
            disabled={aiFilterLoading}
            className="w-full md:w-auto bg-gradient-to-r from-[#f6ad55] to-[#f97316] text-white px-8 py-4 rounded-lg text-lg font-bold hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center mb-6"
          >
            <Bot className="w-6 h-6 mr-2" />
            {aiFilterLoading ? t('admin.aiFilterRunning') : `${t('admin.aiFilter')} (${pendingCount})`}
          </button>
        )}

        <div className="mb-6">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#1a365d]"
          >
            <option value="">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="reviewing">Reviewing</option>
            <option value="shortlisted">Shortlisted</option>
            <option value="ai-shortlisted">AI Shortlisted</option>
            <option value="rejected">Rejected</option>
            <option value="ai-rejected">AI Rejected</option>
            <option value="interview">Interview</option>
            <option value="accepted">Accepted</option>
          </select>
        </div>

        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Name</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Email</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Experience</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Education</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Salary</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Status</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">AI Score</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredApplications.map((application) => (
                  <tr key={application.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm text-gray-900">{application.full_name_en}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{application.email}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{application.total_experience} yrs</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{application.highest_education || 'N/A'}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">
                      {application.expected_salary} {application.salary_currency}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(application.status)}`}>
                        {application.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm font-semibold text-gray-900">
                      {application.ai_score !== null ? `${application.ai_score.toFixed(0)}/100` : '-'}
                    </td>
                    <td className="px-4 py-3">
                      <Link
                        to={`/admin/applications/${application.id}`}
                        className="text-[#1a365d] hover:text-[#f6ad55] font-medium"
                      >
                        {t('admin.view')}
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
