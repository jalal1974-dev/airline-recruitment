import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase, Application, Job } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

export default function MyApplications() {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [applications, setApplications] = useState<(Application & { jobs: Job })[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    fetchApplications();
  }, [user]);

  async function fetchApplications() {
    try {
      const { data, error } = await supabase
        .from('applications')
        .select('*, jobs(*)')
        .eq('user_id', user!.id)
        .order('applied_at', { ascending: false });

      if (error) throw error;
      setApplications(data || []);
    } catch (error) {
      console.error('Error fetching applications:', error);
    } finally {
      setLoading(false);
    }
  }

  const getStatusColor = (status: string) => {
    const statusColors: { [key: string]: string } = {
      pending: 'bg-yellow-100 text-yellow-700',
      reviewing: 'bg-blue-100 text-blue-700',
      shortlisted: 'bg-green-100 text-green-700',
      rejected: 'bg-red-100 text-red-700',
      interview: 'bg-purple-100 text-purple-700',
      accepted: 'bg-green-200 text-green-800',
      'ai-shortlisted': 'bg-teal-100 text-teal-700',
      'ai-rejected': 'bg-orange-100 text-orange-700',
    };
    return statusColors[status] || 'bg-gray-100 text-gray-700';
  };

  const getStatusLabel = (status: string) => {
    const statusMap: { [key: string]: string } = {
      pending: t('myApplications.pending'),
      reviewing: t('myApplications.reviewing'),
      shortlisted: t('myApplications.shortlisted'),
      rejected: t('myApplications.rejected'),
      interview: t('myApplications.interview'),
      accepted: t('myApplications.accepted'),
      'ai-shortlisted': t('myApplications.aiShortlisted'),
      'ai-rejected': t('myApplications.aiRejected'),
    };
    return statusMap[status] || status;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-xl text-gray-600">{t('common.loading')}</p>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
      <Navbar />

      <div className="flex-1 max-w-7xl mx-auto px-4 py-12 w-full">
        <h1 className="text-4xl font-bold text-[#1a365d] mb-8">{t('myApplications.title')}</h1>

        {applications.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-12 text-center">
            <p className="text-xl text-gray-600 mb-6">{t('myApplications.noApplications')}</p>
            <Link
              to="/jobs"
              className="inline-block bg-[#f6ad55] text-[#1a365d] px-6 py-3 rounded-lg font-semibold hover:bg-[#f6ad55]/90 transition"
            >
              {t('home.browseJobs')}
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {applications.map((application) => (
              <div key={application.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div className="flex-1 mb-4 md:mb-0">
                    <h3 className="text-2xl font-bold text-[#1a365d] mb-2">
                      {i18n.language === 'ar' ? application.jobs.title_ar : application.jobs.title_en}
                    </h3>
                    <div className="space-y-1 text-gray-600">
                      <p>
                        <span className="font-medium">{t('myApplications.department')}:</span>{' '}
                        {i18n.language === 'ar' ? application.jobs.department_ar : application.jobs.department_en}
                      </p>
                      <p>
                        <span className="font-medium">{t('myApplications.appliedDate')}:</span>{' '}
                        {new Date(application.applied_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col items-start md:items-end space-y-2">
                    <span className={`px-4 py-2 rounded-full text-sm font-semibold ${getStatusColor(application.status)}`}>
                      {getStatusLabel(application.status)}
                    </span>
                    {application.ai_score !== null && (
                      <span className="text-sm text-gray-600">
                        {t('admin.aiScore')}: {application.ai_score.toFixed(0)}/100
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
