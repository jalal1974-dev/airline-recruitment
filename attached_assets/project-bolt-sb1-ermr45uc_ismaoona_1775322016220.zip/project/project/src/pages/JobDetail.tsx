import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { supabase, Job } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { MapPin, Briefcase, DollarSign, Calendar, GraduationCap, Clock } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

export default function JobDetail() {
  const { id } = useParams<{ id: string }>();
  const { t, i18n } = useTranslation();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [job, setJob] = useState<Job | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchJob();
    }
  }, [id]);

  async function fetchJob() {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('id', id)
        .eq('is_active', true)
        .maybeSingle();

      if (error) throw error;
      setJob(data);
    } catch (error) {
      console.error('Error fetching job:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleApply = () => {
    if (!user) {
      navigate('/login');
    } else {
      navigate(`/apply/${id}`);
    }
  };

  const getEducationLabel = (level: string) => {
    const levelMap: { [key: string]: string } = {
      'high-school': t('jobDetail.highSchool'),
      'diploma': t('jobDetail.diploma'),
      'bachelor': t('jobDetail.bachelor'),
      'master': t('jobDetail.master'),
      'phd': t('jobDetail.phd'),
    };
    return levelMap[level] || level;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <p className="text-xl text-gray-600">{t('common.loading')}</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <p className="text-xl text-gray-600 mb-4">Job not found</p>
            <Link to="/jobs" className="text-[#1a365d] hover:text-[#f6ad55]">{t('common.back')}</Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const qualifications = i18n.language === 'ar' ? job.qualifications_ar : job.qualifications_en;
  const requirements = i18n.language === 'ar' ? job.requirements_ar : job.requirements_en;
  const responsibilities = i18n.language === 'ar' ? job.responsibilities_ar : job.responsibilities_en;

  return (
    <div className="min-h-screen bg-[#f7f8fc] flex flex-col">
      <Navbar />

      <div className="flex-1 max-w-5xl mx-auto px-4 py-12 w-full">
        <Link to="/jobs" className="text-[#1a365d] hover:text-[#f6ad55] mb-6 inline-block">
          ← {t('common.back')}
        </Link>

        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-4xl font-bold text-[#1a365d] mb-6">
            {i18n.language === 'ar' ? job.title_ar : job.title_en}
          </h1>

          <div className="flex flex-wrap gap-3 mb-6">
            <span className="px-4 py-2 bg-blue-100 text-blue-700 text-sm rounded-full flex items-center">
              <Briefcase className="w-4 h-4 mr-2" />
              {i18n.language === 'ar' ? job.department_ar : job.department_en}
            </span>
            <span className="px-4 py-2 bg-green-100 text-green-700 text-sm rounded-full flex items-center">
              <MapPin className="w-4 h-4 mr-2" />
              {i18n.language === 'ar' ? job.location_ar : job.location_en}
            </span>
            <span className="px-4 py-2 bg-purple-100 text-purple-700 text-sm rounded-full flex items-center">
              <GraduationCap className="w-4 h-4 mr-2" />
              {getEducationLabel(job.education_level)}
            </span>
          </div>

          <section className="mb-8">
            <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('jobDetail.description')}</h2>
            <p className="text-gray-700 whitespace-pre-line">
              {i18n.language === 'ar' ? job.description_ar : job.description_en}
            </p>
          </section>

          {qualifications && qualifications.length > 0 && (
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('jobDetail.qualifications')}</h2>
              <ul className="list-disc list-inside space-y-2 text-gray-700">
                {qualifications.map((qual, idx) => (
                  <li key={idx}>{qual}</li>
                ))}
              </ul>
            </section>
          )}

          {requirements && requirements.length > 0 && (
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('jobDetail.requirements')}</h2>
              <ul className="list-disc list-inside space-y-2 text-gray-700">
                {requirements.map((req, idx) => (
                  <li key={idx}>{req}</li>
                ))}
              </ul>
            </section>
          )}

          {responsibilities && responsibilities.length > 0 && (
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('jobDetail.responsibilities')}</h2>
              <ul className="list-disc list-inside space-y-2 text-gray-700">
                {responsibilities.map((resp, idx) => (
                  <li key={idx}>{resp}</li>
                ))}
              </ul>
            </section>
          )}

          {job.skills && job.skills.length > 0 && (
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-[#1a365d] mb-4">{t('jobDetail.skills')}</h2>
              <div className="flex flex-wrap gap-2">
                {job.skills.map((skill, idx) => (
                  <span key={idx} className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full">
                    {skill}
                  </span>
                ))}
              </div>
            </section>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8 p-6 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <Clock className="w-5 h-5 text-[#1a365d] mr-3" />
              <div>
                <p className="text-sm text-gray-600">{t('jobDetail.experience')}</p>
                <p className="font-semibold">{job.experience_min} - {job.experience_max} {t('jobDetail.years')}</p>
              </div>
            </div>

            <div className="flex items-center">
              <DollarSign className="w-5 h-5 text-[#1a365d] mr-3" />
              <div>
                <p className="text-sm text-gray-600">{t('jobDetail.salary')}</p>
                <p className="font-semibold">{job.salary_min} - {job.salary_max} {job.salary_currency}</p>
              </div>
            </div>

            <div className="flex items-center">
              <Calendar className="w-5 h-5 text-[#1a365d] mr-3" />
              <div>
                <p className="text-sm text-gray-600">{t('jobDetail.deadline')}</p>
                <p className="font-semibold">{new Date(job.deadline).toLocaleDateString()}</p>
              </div>
            </div>
          </div>

          <button
            onClick={handleApply}
            className="w-full bg-[#f6ad55] text-[#1a365d] px-8 py-4 rounded-lg text-lg font-bold hover:bg-[#f6ad55]/90 transition"
          >
            {t('jobDetail.applyNow')}
          </button>
        </div>
      </div>

      <Footer />
    </div>
  );
}
