import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface Job {
  id: string;
  ai_min_experience: number;
  ai_required_skills: string[];
  ai_required_education: string;
  ai_max_salary: number;
}

interface Application {
  id: string;
  total_experience: number;
  highest_education: string;
  skills: string[];
  expected_salary: number;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { jobId } = await req.json();

    const { data: job, error: jobError } = await supabase
      .from('jobs')
      .select('*')
      .eq('id', jobId)
      .single();

    if (jobError) throw jobError;

    const { data: applications, error: appsError } = await supabase
      .from('applications')
      .select('*')
      .eq('job_id', jobId)
      .eq('status', 'pending');

    if (appsError) throw appsError;

    let shortlisted = 0;
    let forReview = 0;
    let rejected = 0;

    for (const application of applications) {
      const result = calculateScore(job, application);

      const { error: updateError } = await supabase
        .from('applications')
        .update({
          ai_score: result.score,
          ai_analysis: result.analysis,
          status: result.status,
        })
        .eq('id', application.id);

      if (updateError) {
        console.error(`Error updating application ${application.id}:`, updateError);
        continue;
      }

      if (result.status === 'ai-shortlisted') shortlisted++;
      else if (result.status === 'reviewing') forReview++;
      else if (result.status === 'ai-rejected') rejected++;
    }

    return new Response(
      JSON.stringify({
        success: true,
        shortlisted,
        forReview,
        rejected,
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});

function calculateScore(job: Job, application: Application): { score: number; analysis: string; status: string } {
  let score = 0;
  const matched: string[] = [];
  const missing: string[] = [];

  const experienceScore = calculateExperienceScore(
    job.ai_min_experience || 0,
    application.total_experience
  );
  score += experienceScore;
  if (experienceScore >= 25) {
    matched.push(`Experience: ${application.total_experience} years (Required: ${job.ai_min_experience})`);
  } else {
    missing.push(`Insufficient experience: ${application.total_experience} years (Required: ${job.ai_min_experience})`);
  }

  const educationScore = calculateEducationScore(
    job.ai_required_education || '',
    application.highest_education || ''
  );
  score += educationScore;
  if (educationScore >= 20) {
    matched.push(`Education: ${application.highest_education}`);
  } else {
    missing.push(`Education level below requirement: ${application.highest_education} (Required: ${job.ai_required_education})`);
  }

  const skillsScore = calculateSkillsScore(
    job.ai_required_skills || [],
    application.skills || []
  );
  score += skillsScore;
  if (skillsScore >= 20) {
    const matchedSkills = (job.ai_required_skills || []).filter(s =>
      (application.skills || []).some(as => as.toLowerCase() === s.toLowerCase())
    );
    matched.push(`Skills: ${matchedSkills.join(', ')}`);
  } else {
    const missingSkills = (job.ai_required_skills || []).filter(s =>
      !(application.skills || []).some(as => as.toLowerCase() === s.toLowerCase())
    );
    if (missingSkills.length > 0) {
      missing.push(`Missing skills: ${missingSkills.join(', ')}`);
    }
  }

  const salaryScore = calculateSalaryScore(
    job.ai_max_salary || 0,
    application.expected_salary
  );
  score += salaryScore;
  if (salaryScore >= 15) {
    matched.push(`Salary expectation within budget: ${application.expected_salary}`);
  } else {
    missing.push(`Salary expectation exceeds budget: ${application.expected_salary} (Max: ${job.ai_max_salary})`);
  }

  let status = 'reviewing';
  if (score >= 70) {
    status = 'ai-shortlisted';
  } else if (score < 40) {
    status = 'ai-rejected';
  }

  const analysis = `AI Score: ${score.toFixed(0)}/100\n\nMatched Criteria:\n${matched.map(m => '✓ ' + m).join('\n')}\n\nMissing/Below Criteria:\n${missing.map(m => '✗ ' + m).join('\n')}`;

  return { score, analysis, status };
}

function calculateExperienceScore(required: number, actual: number): number {
  if (required === 0) return 30;
  if (actual >= required) return 30;
  return (actual / required) * 30;
}

function calculateEducationScore(required: string, actual: string): number {
  const levels: { [key: string]: number } = {
    'high-school': 1,
    'diploma': 2,
    'bachelor': 3,
    'master': 4,
    'phd': 5,
  };

  if (!required) return 25;

  const requiredLevel = levels[required] || 0;
  const actualLevel = levels[actual] || 0;

  if (actualLevel >= requiredLevel) return 25;
  if (actualLevel === requiredLevel - 1) return 15;
  return 0;
}

function calculateSkillsScore(required: string[], actual: string[]): number {
  if (!required || required.length === 0) return 25;

  const matchedCount = required.filter(reqSkill =>
    actual.some(actSkill => actSkill.toLowerCase() === reqSkill.toLowerCase())
  ).length;

  return (matchedCount / required.length) * 25;
}

function calculateSalaryScore(maxBudget: number, expected: number): number {
  if (maxBudget === 0) return 20;
  if (expected <= maxBudget) return 20;
  if (expected <= maxBudget * 1.2) return 10;
  return 0;
}
