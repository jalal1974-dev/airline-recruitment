/*
  # Jordan Aviation Careers - Initial Database Schema

  1. New Tables
    - `profiles`
      - Extends auth.users with additional profile information
      - `id` (uuid, references auth.users)
      - `full_name_en` (text)
      - `full_name_ar` (text)
      - `phone` (text)
      - `nationality` (text)
      - `role` (text) - 'applicant' or 'admin'
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `jobs`
      - Job postings with bilingual content
      - `id` (uuid, primary key)
      - `title_en`, `title_ar` (text)
      - `description_en`, `description_ar` (text)
      - `department_en`, `department_ar` (text)
      - `location_en`, `location_ar` (text)
      - `employment_type` (text) - full-time, part-time, contract
      - `education_level` (text) - high-school, diploma, bachelor, master, phd
      - `experience_min`, `experience_max` (integer, years)
      - `salary_min`, `salary_max` (numeric)
      - `salary_currency` (text)
      - `qualifications_en`, `qualifications_ar` (jsonb array)
      - `requirements_en`, `requirements_ar` (jsonb array)
      - `responsibilities_en`, `responsibilities_ar` (jsonb array)
      - `skills` (jsonb array)
      - `deadline` (date)
      - `is_active` (boolean)
      - `ai_min_experience` (integer)
      - `ai_required_skills` (jsonb array)
      - `ai_required_education` (text)
      - `ai_max_salary` (numeric)
      - `ai_custom_criteria` (text)
      - `created_at`, `updated_at` (timestamptz)
    
    - `applications`
      - Job applications with all applicant data
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `job_id` (uuid, references jobs)
      - `full_name_en`, `full_name_ar` (text)
      - `email` (text)
      - `phone` (text)
      - `nationality` (text)
      - `date_of_birth` (date)
      - `gender` (text)
      - `address_en`, `address_ar` (text)
      - `education` (jsonb array)
      - `experience` (jsonb array)
      - `skills` (jsonb array)
      - `languages` (jsonb array)
      - `resume_url` (text)
      - `cover_letter` (text)
      - `total_experience` (integer)
      - `highest_education` (text)
      - `expected_salary` (numeric)
      - `salary_currency` (text)
      - `status` (text) - pending, reviewing, shortlisted, rejected, interview, accepted, ai-shortlisted, ai-rejected
      - `ai_score` (numeric)
      - `ai_analysis` (text)
      - `admin_notes` (text)
      - `applied_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Profiles: Users can read/update own profile, admins can read all
    - Jobs: Public can read active jobs, admins can manage all
    - Applications: Users can create/read own, admins can read/update all
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name_en text NOT NULL,
  full_name_ar text,
  phone text,
  nationality text,
  role text NOT NULL DEFAULT 'applicant' CHECK (role IN ('applicant', 'admin')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id OR EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Create jobs table
CREATE TABLE IF NOT EXISTS jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title_en text NOT NULL,
  title_ar text NOT NULL,
  description_en text NOT NULL,
  description_ar text NOT NULL,
  department_en text NOT NULL,
  department_ar text NOT NULL,
  location_en text NOT NULL,
  location_ar text NOT NULL,
  employment_type text NOT NULL CHECK (employment_type IN ('full-time', 'part-time', 'contract', 'internship')),
  education_level text NOT NULL CHECK (education_level IN ('high-school', 'diploma', 'bachelor', 'master', 'phd')),
  experience_min integer DEFAULT 0,
  experience_max integer DEFAULT 0,
  salary_min numeric DEFAULT 0,
  salary_max numeric DEFAULT 0,
  salary_currency text DEFAULT 'USD',
  qualifications_en jsonb DEFAULT '[]'::jsonb,
  qualifications_ar jsonb DEFAULT '[]'::jsonb,
  requirements_en jsonb DEFAULT '[]'::jsonb,
  requirements_ar jsonb DEFAULT '[]'::jsonb,
  responsibilities_en jsonb DEFAULT '[]'::jsonb,
  responsibilities_ar jsonb DEFAULT '[]'::jsonb,
  skills jsonb DEFAULT '[]'::jsonb,
  deadline date,
  is_active boolean DEFAULT true,
  ai_min_experience integer DEFAULT 0,
  ai_required_skills jsonb DEFAULT '[]'::jsonb,
  ai_required_education text,
  ai_max_salary numeric,
  ai_custom_criteria text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read active jobs"
  ON jobs FOR SELECT
  TO public
  USING (is_active = true);

CREATE POLICY "Admins can read all jobs"
  ON jobs FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Admins can create jobs"
  ON jobs FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Admins can update jobs"
  ON jobs FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Admins can delete jobs"
  ON jobs FOR DELETE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Create applications table
CREATE TABLE IF NOT EXISTS applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  job_id uuid NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  full_name_en text NOT NULL,
  full_name_ar text,
  email text NOT NULL,
  phone text NOT NULL,
  nationality text,
  date_of_birth date,
  gender text CHECK (gender IN ('Male', 'Female', 'Other')),
  address_en text,
  address_ar text,
  education jsonb DEFAULT '[]'::jsonb,
  experience jsonb DEFAULT '[]'::jsonb,
  skills jsonb DEFAULT '[]'::jsonb,
  languages jsonb DEFAULT '[]'::jsonb,
  resume_url text,
  cover_letter text,
  total_experience integer DEFAULT 0,
  highest_education text,
  expected_salary numeric NOT NULL,
  salary_currency text DEFAULT 'USD',
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'reviewing', 'shortlisted', 'rejected', 'interview', 'accepted', 'ai-shortlisted', 'ai-rejected')),
  ai_score numeric,
  ai_analysis text,
  admin_notes text,
  applied_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE applications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own applications"
  ON applications FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create applications"
  ON applications FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can read all applications"
  ON applications FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Admins can update applications"
  ON applications FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_jobs_active ON jobs(is_active);
CREATE INDEX IF NOT EXISTS idx_jobs_deadline ON jobs(deadline);
CREATE INDEX IF NOT EXISTS idx_applications_user ON applications(user_id);
CREATE INDEX IF NOT EXISTS idx_applications_job ON applications(job_id);
CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_jobs_updated_at BEFORE UPDATE ON jobs
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_applications_updated_at BEFORE UPDATE ON applications
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();